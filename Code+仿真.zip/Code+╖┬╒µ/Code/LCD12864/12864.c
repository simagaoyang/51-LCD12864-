#include <12864.h>
#include <intrins.h>
#include <string.h>
#include "shuzi.h"  //字符库头文件
#include "hanzi.h"  //字符库头文件
//*********************************************//
// 函数声明
void init_lcd12864(void);
void lcd12864_delay(unsigned int time);            //延时
void lcd12864_write_com(unsigned char cmdcode);    //写命令
void lcd12864_write_data(unsigned char Rsspdata);  //写数据
void lcd12864_Clr_Scr(void);               //清屏
void lcd12864_werite_x_y(unsigned char x,unsigned char y); //写地址
void lcd_write_chinese(unsigned char x,unsigned char y, unsigned char hz,unsigned char *dat); //任意位置显示任意汉字
void lcd12864_write_english(unsigned char x,unsigned char y, unsigned char en,unsigned char *dat); //任意位置显示任意字符
/*以下为LCD通信协议*/
//---------------------------------------
//   延时函数
//---------------------------------------
void lcd12864_delay(unsigned int time)
{
          unsigned int i;
          for(i=0;i<time;i++);
}
//---------------------------------------
//   12864初始化函数
//---------------------------------------
void init_lcd12864(void)
{           
          LCD12864_RST=0;              //液晶复位
          lcd12864_delay(250);         //适当延时
          LCD12864_RST=1;              //复位结束
          LCD12864_CS1=1;                         //左半屏选通
          LCD12864_CS2=1;                             //右半屏选通        
          lcd12864_delay(250);         //适当延时
          lcd12864_write_com(0x3f);    //显示开
}
//---------------------------------------
//   写命令函数
//---------------------------------------
void lcd12864_write_com(unsigned char cmdcode)
{                                          
          LCD12864_RS=0;                        //选择命令寄存器
          LCD12864_RW=0;                         //写选通
          LCD12864_DATA=cmdcode;   //将命令写入总线
          _nop_();            //空操作，做短暂的延时
          LCD12864_EN=1;           //E的下降沿，数据写入
          _nop_();            //空操作，做短暂的延时
          LCD12864_EN=0;           //E的下降沿，数据写入
}
//---------------------------------------
//   写数据函数
//---------------------------------------
void lcd12864_write_data(unsigned char Rsspdata)
{

          LCD12864_RS=1;                        //选择数据寄存器
          LCD12864_RW=0;                         //写选通
          LCD12864_DATA=Rsspdata;  //将数据写入总线
          _nop_();            //空操作，做短暂的延时
          LCD12864_EN=1;           //E的下降沿，数据写入
          _nop_();            //空操作，做短暂的延时
          LCD12864_EN=0;           //E的下降沿，数据写入
}
//---------------------------------------
//   清屏函数
//---------------------------------------
void lcd12864_Clr_Scr(void)
{
          unsigned char j,k;
          LCD12864_CS1=1;                                           //左半屏选通
          LCD12864_CS2=1;                                           //右半屏选通
          lcd12864_write_com(0x40+0);        //将列地址写入  
          for(k=0;k<8;k++)
          {
                    lcd12864_write_com(0xb8+k);    //将行地址写入        
                    for(j=0;j<64;j++)               //每行的64列都写0，因为选了左右两屏，
                    {
                              lcd12864_write_data(0x00); //64列同时写0
                    }
          }
}
//---------------------------------------
//    地址写入函数
//---------------------------------------
void lcd12864_werite_x_y(unsigned char x,unsigned char y)
{
          y=y&0x7f;                                 //限定范围，列不能超过128
          x=x&0x07;                             //限定范围，行不能超过8
          if(y<64)                    //如果列小于64
          {
                    LCD12864_CS1=0;                  //选通左半屏
                    LCD12864_CS2=1;                  //关闭右半屏
                    lcd12864_write_com(0x40+y);  //将列地址写入  
          }
          else
          {
                    LCD12864_CS1=1;                  //关闭左半屏
                    LCD12864_CS2=0;                  //选通右半屏
                    y&=0x3f;
                    lcd12864_write_com(0x40+y);  //将列地址写入         
          }
          lcd12864_write_com(0xb8+x);      //将行地址写入        
}       
//---------------------------------------
//     指定位置写8*16字符函数
//---------------------------------------
void lcd12864_write_english(unsigned char x,unsigned char y, unsigned char en,unsigned char *dat)
{
    unsigned char i=0;        
		lcd12864_werite_x_y(x,y);            //设定起始地址
		for(i=0;i<8;i++)
		lcd12864_write_data(dat[en*16+i]);   //先写上半个字，共8个字节
		lcd12864_werite_x_y(x+1,y);          //设定起始地址，此次将行地址加1，以便写下行
		for(i=0;i<8;i++)
		lcd12864_write_data(dat[en*16+8+i]); //再写下半个字，共8个字节
}
//---------------------------------------
//     指定位置写16*16汉字函数
//---------------------------------------
void lcd_write_chinese(unsigned char x,unsigned char y, unsigned char hz,unsigned char *dat)
{
	  unsigned char i=0;	
	  lcd12864_werite_x_y(x,y);             //设定起始地址
	  for(i=0;i<16;i++) 
	  lcd12864_write_data(dat[hz*32+i]);    //先写上半个字，共16个字节
	  lcd12864_werite_x_y(x+1,y);           //设定起始地址，此次将行地址加1，以便写下行
	  for(i=0;i<16;i++) 
	  lcd12864_write_data(dat[hz*32+16+i]); //再写下半个字，共16个字节
}
void LCD12864_Display(unsigned char y,unsigned char x,unsigned char num,unsigned char flag)//flag为1,显示数字,0显示汉字
{
	if(flag)
		lcd12864_write_english(x*2,y*8,num,SHUZI);
	else
		lcd_write_chinese(x*2,y*8,num,HANZI);
}